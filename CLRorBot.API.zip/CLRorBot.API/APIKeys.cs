namespace gateio.api
{
    public static class APIKeys
    {
        /// <summary>
        /// Key
        /// </summary>
        internal static string KEY { get; set; }

        /// <summary>
        /// 秘钥
        /// </summary>
        internal static string SECRET { get; set; }

    }
}